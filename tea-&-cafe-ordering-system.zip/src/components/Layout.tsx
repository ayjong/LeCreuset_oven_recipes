import { Outlet, Link } from 'react-router-dom';
import { User, signOut } from 'firebase/auth';
import { auth } from '../firebase';
import { Coffee, LogOut, User as UserIcon } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

export default function Layout({ user, isAdmin }: { user: User | null, isAdmin: boolean }) {
  const handleLogout = async () => {
    await signOut(auth);
  };

  return (
    <div className="min-h-screen bg-[#f5f0e6] flex flex-col font-sans text-stone-800">
      <header className="sticky top-0 z-50 bg-[#2d3a2a] text-[#f5f0e6] shadow-md border-b-[4px] border-[#daaa4a]">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-bold text-xl md:text-2xl tracking-wide uppercase font-serif">
            <Coffee className="w-6 h-6 text-[#daaa4a]" />
            十月茶餐廳 <span className="text-sm font-sans normal-case opacity-80 hidden sm:inline">(October Cafe)</span>
          </Link>
          
          <nav className="flex items-center gap-4 text-sm font-medium">
            {user ? (
              <>
                <Link to="/orders" className="hover:text-[#daaa4a] transition-colors">My Orders</Link>
                {isAdmin && (
                  <Link to="/admin" className="hover:text-[#daaa4a] transition-colors text-[#daaa4a]">Admin</Link>
                )}
                <div className="flex items-center gap-2 pl-4 border-l border-white/20">
                  <UserIcon className="w-4 h-4 opacity-70" />
                  <span className="hidden md:inline truncate max-w-[120px]">{user.email?.split('@')[0]}</span>
                  <button 
                    onClick={handleLogout}
                    className="ml-2 hover:bg-white/10 p-2 rounded-full transition-colors group"
                    title="Sign Out"
                  >
                    <LogOut className="w-4 h-4 group-hover:text-red-400" />
                  </button>
                </div>
              </>
            ) : (
              <Link 
                to="/login"
                className="bg-[#daaa4a] text-[#2d3a2a] px-4 py-2 rounded-md font-bold hover:bg-[#eac47a] transition-colors shadow-sm"
              >
                Sign In
              </Link>
            )}
          </nav>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="h-full"
        >
          <Outlet />
        </motion.div>
      </main>

      <footer className="bg-[#2d3a2a] text-[#f5f0e6]/60 py-6 text-center text-sm border-t-8 border-[#3b4c37]">
        <p>© {new Date().getFullYear()} October Cafe Ordering System. All rights reserved.</p>
      </footer>
    </div>
  );
}
