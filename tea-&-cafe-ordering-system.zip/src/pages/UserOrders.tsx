import { useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import { collection, onSnapshot, query, where, orderBy, updateDoc, doc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Clock, CheckCircle2, XCircle, Package, ChevronRight } from 'lucide-react';

interface OrderItem {
  name: string;
  price: number;
  qty: number;
  menuId: string;
}

interface Order {
  id: string;
  userId: string;
  items: OrderItem[];
  status: 'pending' | 'preparing' | 'ready' | 'completed' | 'cancelled';
  totalPrice: number;
  createdAt: any;
  updatedAt: any;
}

export default function UserOrders({ user }: { user: User }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'orders'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedOrders: Order[] = [];
      snapshot.forEach(docSnap => {
        fetchedOrders.push({ id: docSnap.id, ...docSnap.data() } as Order);
      });
      setOrders(fetchedOrders);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
    });

    return () => unsubscribe();
  }, [user]);

  const cancelOrder = async (orderId: string) => {
    if (confirm('Cancel this order?')) {
      try {
        await updateDoc(doc(db, 'orders', orderId), { 
          status: 'cancelled',
          updatedAt: serverTimestamp() 
        });
      } catch(error) {
         handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
      }
    }
  };

  const StatusIcon = ({ status }: { status: Order['status'] }) => {
    switch (status) {
      case 'pending': return <Clock className="text-yellow-500 w-5 h-5" />;
      case 'preparing': return <Package className="text-blue-500 w-5 h-5" />;
      case 'ready': return <CheckCircle2 className="text-green-500 w-5 h-5" />;
      case 'completed': return <CheckCircle2 className="text-stone-400 w-5 h-5" />;
      case 'cancelled': return <XCircle className="text-red-500 w-5 h-5" />;
      default: return null;
    }
  };

  if (loading) {
    return <div className="text-center py-20 text-stone-500">Loading your orders...</div>;
  }

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-[#2d3a2a] mb-8">Order History</h1>
      
      {orders.length === 0 ? (
        <div className="bg-white p-10 rounded-xl text-center shadow-sm border border-stone-200">
          <p className="text-stone-500 mb-4">You have not placed any orders yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <div key={order.id} className="bg-white rounded-xl p-6 shadow-sm border border-stone-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 pb-4 border-b border-stone-100 gap-4">
                <div>
                  <p className="text-xs text-stone-400 font-mono">Order #{order.id.slice(0, 8).toUpperCase()}</p>
                  <p className="text-sm text-stone-600 mt-1">
                    {order.createdAt?.toDate ? order.createdAt.toDate().toLocaleString() : 'Processing time...'}
                  </p>
                </div>
                <div className="flex items-center gap-2 bg-stone-50 px-3 py-1.5 rounded-full border border-stone-100">
                  <StatusIcon status={order.status} />
                  <span className="text-sm font-bold uppercase tracking-wider capitalize text-stone-700">
                    {order.status}
                  </span>
                </div>
              </div>

              <div className="space-y-2 mb-6">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="text-stone-700 font-medium">
                      {item.qty}x {item.name}
                    </span>
                    <span className="text-stone-500">${item.price * item.qty}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-stone-100">
                <span className="text-lg font-bold text-[#2d3a2a]">Total: ${order.totalPrice}</span>
                {order.status === 'pending' && (
                  <button 
                    onClick={() => cancelOrder(order.id)}
                    className="text-red-500 hover:bg-red-50 px-4 py-2 rounded-md transition-colors text-sm font-medium border border-transparent hover:border-red-100"
                  >
                    Cancel Order
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
