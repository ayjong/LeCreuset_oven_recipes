import { useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import { collection, onSnapshot, query, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { ShoppingCart, Plus, Minus, Check, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface MenuItem {
  id: string;
  category: string;
  name: string;
  price: number;
  available: boolean;
}

interface CartItem extends MenuItem {
  qty: number;
}

export default function Home({ user }: { user: User | null }) {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [ordering, setOrdering] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const q = query(collection(db, 'menuItems'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: MenuItem[] = [];
      snapshot.forEach(doc => {
        items.push({ id: doc.id, ...doc.data() } as MenuItem);
      });
      setMenuItems(items);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'menuItems');
    });

    return () => unsubscribe();
  }, []);

  const categories = Array.from(new Set(menuItems.map(item => item.category)));

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i);
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === itemId);
      if (existing && existing.qty > 1) {
        return prev.map(i => i.id === itemId ? { ...i, qty: i.qty - 1 } : i);
      }
      return prev.filter(i => i.id !== itemId);
    });
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const itemCount = cart.reduce((sum, item) => sum + item.qty, 0);

  const handleCheckout = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (cart.length === 0) return;

    setOrdering(true);
    try {
      const orderData = {
        userId: user.uid,
        items: cart.map(item => ({ menuId: item.id, name: item.name, price: item.price, qty: item.qty })),
        status: 'pending',
        totalPrice: cartTotal,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      await addDoc(collection(db, 'orders'), orderData);
      setCart([]);
      navigate('/orders');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'orders');
    } finally {
      setOrdering(false);
    }
  };

  if (loading) {
    return <div className="py-20 text-center text-stone-500">Loading menu...</div>;
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8 relative">
      <div className="flex-1">
        {menuItems.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-stone-200">
            <h2 className="text-xl font-bold text-stone-700 mb-2">Menu is empty</h2>
            <p className="text-stone-500">Admins need to set up the menu items.</p>
          </div>
        ) : (
          <div className="space-y-10">
            {categories.map((category) => (
              <div key={category} className="bg-white p-6 rounded-xl shadow-sm border-t-4 border-[#2d3a2a]">
                <h2 className="text-2xl font-bold text-[#2d3a2a] mb-6 flex items-center gap-2">
                   <span className="w-2 h-6 bg-[#daaa4a] rounded-sm inline-block"></span>
                   {category}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {menuItems.filter(i => i.category === category).map((item) => (
                    <div 
                      key={item.id} 
                      className={`flex justify-between items-center p-4 rounded-lg border ${item.available ? 'border-stone-200 hover:border-[#daaa4a] hover:bg-stone-50' : 'border-stone-100 bg-stone-50 opacity-50'} transition-all`}
                    >
                      <div>
                        <h3 className="font-medium text-stone-800">{item.name}</h3>
                        <p className="text-[#daaa4a] font-bold mt-1">${item.price}</p>
                      </div>
                      {item.available ? (
                        <button 
                          onClick={() => addToCart(item)}
                          className="bg-[#2d3a2a] text-white p-2 rounded-full hover:bg-stone-700 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      ) : (
                        <span className="text-xs font-medium text-red-500 bg-red-50 px-2 py-1 rounded-full">Sold Out</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="w-full lg:w-96 lg:sticky lg:top-24 h-max order-first lg:order-last mb-8 lg:mb-0">
        <div className="bg-white p-6 rounded-xl shadow-lg border border-stone-200">
          <h2 className="text-xl font-bold text-stone-800 mb-6 flex items-center gap-2 border-b pb-4">
            <ShoppingCart className="w-5 h-5 text-[#daaa4a]" />
            Your Order
          </h2>
          
          {cart.length === 0 ? (
            <div className="text-center py-10 text-stone-400">
              <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>Your cart is empty</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center justify-between group">
                  <div className="flex-1 pr-4">
                    <h4 className="text-sm font-medium text-stone-800 leading-tight">{item.name}</h4>
                    <p className="text-xs text-stone-500 mt-1">${item.price}</p>
                  </div>
                  <div className="flex items-center gap-3 bg-stone-100 rounded-lg p-1 border border-stone-200">
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="text-stone-500 hover:text-red-500 hover:bg-white p-1 rounded-md transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-sm font-bold w-4 text-center">{item.qty}</span>
                    <button 
                      onClick={() => addToCart(item)}
                      className="text-stone-500 hover:text-green-600 hover:bg-white p-1 rounded-md transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {cart.length > 0 && (
            <div className="mt-8 pt-4 border-t border-stone-100">
              <div className="flex justify-between items-center mb-6">
                <span className="text-stone-500 font-medium">Total ({itemCount} items)</span>
                <span className="text-2xl font-bold text-[#2d3a2a]">${cartTotal}</span>
              </div>
              <button 
                onClick={handleCheckout}
                disabled={ordering}
                className="w-full bg-[#daaa4a] hover:bg-[#c99a3e] text-[#2d3a2a] font-bold py-4 rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 group disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {ordering ? 'Processing...' : (
                  <>
                    Checkout <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
              {!user && (
                <p className="text-xs text-center text-stone-500 mt-3">
                  You will be prompted to login
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
