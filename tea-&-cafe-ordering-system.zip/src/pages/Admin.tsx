import { useEffect, useState } from 'react';
import { collection, onSnapshot, query, updateDoc, doc, addDoc, serverTimestamp, orderBy, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Plus, Trash2, Edit2 } from 'lucide-react';

export default function Admin() {
  const [activeTab, setActiveTab] = useState<'orders' | 'menu'>('orders');
  
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold text-[#2d3a2a] mb-8">Admin Dashboard</h1>
      
      <div className="flex gap-4 mb-8 border-b border-stone-200">
        <button 
          onClick={() => setActiveTab('orders')}
          className={`pb-4 px-2 font-medium text-lg border-b-2 transition-colors ${activeTab === 'orders' ? 'border-[#daaa4a] text-[#daaa4a]' : 'border-transparent text-stone-500 hover:text-stone-700'}`}
        >
          Manage Orders
        </button>
        <button 
          onClick={() => setActiveTab('menu')}
          className={`pb-4 px-2 font-medium text-lg border-b-2 transition-colors ${activeTab === 'menu' ? 'border-[#daaa4a] text-[#daaa4a]' : 'border-transparent text-stone-500 hover:text-stone-700'}`}
        >
          Manage Menu
        </button>
      </div>

      {activeTab === 'orders' ? <ManageOrders /> : <ManageMenu />}
    </div>
  );
}

function ManageOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  
  useEffect(() => {
    // Admin list all orders
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedOrders: any[] = [];
      snapshot.forEach(docSnap => {
        fetchedOrders.push({ id: docSnap.id, ...docSnap.data() });
      });
      setOrders(fetchedOrders);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'orders'));

    return () => unsubscribe();
  }, []);

  const updateStatus = async (orderId: string, newStatus: string) => {
    try {
       await updateDoc(doc(db, 'orders', orderId), { 
         status: newStatus,
         updatedAt: serverTimestamp() 
       });
    } catch(err) {
       handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  return (
    <div className="overflow-x-auto bg-white rounded-xl shadow-sm border border-stone-200">
      <table className="w-full text-left">
        <thead className="bg-[#2d3a2a] text-[#f5f0e6]">
          <tr>
            <th className="p-4 font-medium">Order ID</th>
            <th className="p-4 font-medium">Date</th>
            <th className="p-4 font-medium">Items</th>
            <th className="p-4 font-medium">Total</th>
            <th className="p-4 font-medium">Status</th>
            <th className="p-4 font-medium">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-stone-100">
          {orders.map(order => (
            <tr key={order.id} className="hover:bg-stone-50">
              <td className="p-4 font-mono text-xs text-stone-500">{order.id.slice(0, 8)}</td>
              <td className="p-4 text-sm">{order.createdAt?.toDate ? order.createdAt.toDate().toLocaleString() : ''}</td>
              <td className="p-4 text-sm">
                {order.items.map((item: any, i: number) => (
                  <div key={i}>{item.qty}x {item.name}</div>
                ))}
              </td>
              <td className="p-4 font-bold text-[#2d3a2a]">${order.totalPrice}</td>
              <td className="p-4">
                <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase tracking-wide
                  ${order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''}
                  ${order.status === 'preparing' ? 'bg-blue-100 text-blue-800' : ''}
                  ${order.status === 'ready' ? 'bg-green-100 text-green-800' : ''}
                  ${order.status === 'completed' ? 'bg-stone-100 text-stone-800' : ''}
                  ${order.status === 'cancelled' ? 'bg-red-100 text-red-800' : ''}
                `}>
                  {order.status}
                </span>
              </td>
              <td className="p-4">
                <select 
                  value={order.status}
                  onChange={(e) => updateStatus(order.id, e.target.value)}
                  className="border border-stone-300 rounded p-1 text-sm bg-white"
                >
                  <option value="pending">Pending</option>
                  <option value="preparing">Preparing</option>
                  <option value="ready">Ready</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </td>
            </tr>
          ))}
          {orders.length === 0 && (
             <tr>
               <td colSpan={6} className="p-8 text-center text-stone-500">No orders found.</td>
             </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

const DEFAULT_MENU = [
  { category: '招牌蔥油系列', name: '招牌蔥油雞腿扒炒麵', price: 240, available: true },
  { category: '招牌蔥油系列', name: '招牌蔥油叉燒炒麵', price: 240, available: true },
  { category: '招牌蔥油系列', name: '招牌蔥油太陽蛋雞腿扒飯', price: 220, available: true },
  { category: '碟頭飯系列', name: '鹹蛋蒸肉餅飯', price: 200, available: true },
  { category: '碟頭飯系列', name: '豬扒蛋飯', price: 190, available: true },
  { category: '碟頭飯系列', name: '雞腿扒蛋飯', price: 190, available: true },
  { category: '有鑊氣系列', name: '蝦醬海鮮炒飯', price: 250, available: true },
  { category: '有鑊氣系列', name: '太極鴛鴦炒飯', price: 230, available: true },
  { category: '有鑊氣系列', name: '乾炒牛河', price: 230, available: true },
  { category: '港式巨無霸三文治系列', name: '沙嗲牛肉滑蛋三文治', price: 180, available: true },
  { category: '港式懷舊點心系列', name: '鮑魚燒賣皇(3粒)', price: 190, available: true },
  { category: '港式懷舊點心系列', name: '黑金流沙包(3個)', price: 140, available: true },
  { category: '特飲', name: '忌廉溝鮮奶', price: 120, available: true },
  { category: '飲料', name: '港式絲襪奶茶', price: 80, available: true },
  { category: '飲料', name: '港式檸檬茶', price: 80, available: true },
  { category: '單點', name: '咖央西多士', price: 120, available: true },
  { category: '常餐', name: '常餐 (公仔麵 配 煎蛋及奶茶)', price: 200, available: true },
];

function ManageMenu() {
  const [items, setItems] = useState<any[]>([]);
  const [seeding, setSeeding] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'menuItems'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched: any[] = [];
      snapshot.forEach(docSnap => {
        fetched.push({ id: docSnap.id, ...docSnap.data() });
      });
      setItems(fetched);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'menuItems'));

    return () => unsubscribe();
  }, []);

  const seedDatabase = async () => {
    setSeeding(true);
    try {
      for (const item of DEFAULT_MENU) {
        await addDoc(collection(db, 'menuItems'), item);
      }
    } catch(err) {
      alert("Error seeding: " + String(err));
      try { handleFirestoreError(err, OperationType.CREATE, 'menuItems'); } catch(e) {}
    } finally {
      setSeeding(false);
    }
  };

  const toggleAvailability = async (id: string, currentVal: boolean) => {
    try {
      await updateDoc(doc(db, 'menuItems', id), { available: !currentVal });
    } catch(err) {
      handleFirestoreError(err, OperationType.UPDATE, `menuItems/${id}`);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Menu Items</h2>
        <div className="flex gap-4">
          <button 
            onClick={seedDatabase}
            disabled={seeding}
            className="bg-stone-200 text-stone-700 px-4 py-2 rounded-md font-medium hover:bg-stone-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {seeding ? 'Seeding...' : 'Seed Initial Data'}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-stone-50 text-stone-500 border-b border-stone-200">
            <tr>
              <th className="p-4 font-medium">Category</th>
              <th className="p-4 font-medium">Name</th>
              <th className="p-4 font-medium">Price</th>
              <th className="p-4 font-medium">Status</th>
              <th className="p-4 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {items.map(item => (
              <tr key={item.id} className="hover:bg-stone-50">
                <td className="p-4 text-sm text-stone-500">{item.category}</td>
                <td className="p-4 font-medium text-stone-800">{item.name}</td>
                <td className="p-4 text-stone-600">${item.price}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${item.available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {item.available ? 'Available' : 'Sold Out'}
                  </span>
                </td>
                <td className="p-4 text-right">
                  <button 
                    onClick={() => toggleAvailability(item.id, item.available)}
                    className="text-sm font-medium text-blue-600 hover:text-blue-800 underline"
                  >
                    Toggle Status
                  </button>
                </td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={5} className="p-10 text-center text-stone-500">
                  <p className="mb-4">No menu items found.</p>
                  <button onClick={seedDatabase} className="text-[#daaa4a] font-bold underline">Click here to seed default menu</button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
