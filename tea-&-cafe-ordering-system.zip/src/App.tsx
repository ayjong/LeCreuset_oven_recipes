import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

import Home from './pages/Home';
import Login from './pages/Login';
import Admin from './pages/Admin';
import UserOrders from './pages/UserOrders';
import Layout from './components/Layout';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // If user is logged in, check if they are an admin via hardcoded email or role in DB
        // For bootstrapped admin, it's ayjong@gmail.com
        if (currentUser.email === 'ayjong@gmail.com') {
          setIsAdmin(true);
        } else {
          setIsAdmin(false);
        }
        
        // Ensure user profile exists
        try {
          const userDocRef = doc(db, 'users', currentUser.uid);
          const userSnap = await getDoc(userDocRef);
          if (!userSnap.exists()) {
            await setDoc(userDocRef, {
              email: currentUser.email,
              role: currentUser.email === 'ayjong@gmail.com' ? 'admin' : 'user',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            });
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${currentUser.uid}`);
        }
      } else {
        setIsAdmin(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-stone-50">Loading...</div>;
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout user={user} isAdmin={isAdmin} />}>
          <Route index element={<Home user={user} />} />
          <Route path="login" element={<Login />} />
          <Route path="orders" element={user ? <UserOrders user={user} /> : <Navigate to="/login" />} />
          <Route path="admin" element={isAdmin ? <Admin /> : <Navigate to="/" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
